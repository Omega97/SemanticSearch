import os
import shutil
from sklearn.cluster import KMeans
from semanticsearch.src.database import Database
from semanticsearch.src.embedding import EmbeddingModel, Embeddings


class SemanticFileOrganizer:
    def __init__(self, root_directory, model_name="all-MiniLM-L6-v2", num_clusters=5):
        """
        Initialize the SemanticFileOrganizer.

        Args:
            root_directory (str): The root directory where files are located and will be rearranged.
            model_name (str): The name of the SentenceTransformer model to use for embeddings.
            num_clusters (int): The number of clusters to create.
        """
        self.root_directory = root_directory
        self.model_name = model_name
        self.num_clusters = num_clusters

    def organize_files(self):
        """
        Rearranges files in the root directory into subfolders based on semantic embeddings.
        """
        # Step 1: Move all files to the root directory and delete other directories
        self._flatten_directory()

        # Step 2: Set up the Embeddings
        database = Database(folder_path=self.root_directory)
        embedding_model = EmbeddingModel(model_name=self.model_name)
        embeddings = Embeddings(dir_path=self.root_directory, database=database, embedding_model=embedding_model)

        # Step 3: Perform clustering and get centroids
        names, embedding_matrix = embeddings.to_matrix()
        kmeans = KMeans(n_clusters=self.num_clusters, random_state=42)
        kmeans.fit(embedding_matrix)
        centroids = kmeans.cluster_centers_

        # Step 4: For each centroid, compute the closest file and use it as the folder name
        folder_names = []
        for centroid in centroids:
            closest_index = self._find_closest_embedding(centroid, embedding_matrix)
            closest_file = names[closest_index]
            folder_name = os.path.splitext(closest_file)[0]  # Remove file extension
            folder_names.append(folder_name)

        # Step 5: Create new directories
        for folder_name in folder_names:
            os.makedirs(os.path.join(self.root_directory, folder_name), exist_ok=True)

        # Step 6: Move files to the new directories based on clustering
        labels = kmeans.labels_
        for file_name, label in zip(names, labels):
            source_path = os.path.join(self.root_directory, file_name)
            destination_folder = folder_names[label]
            destination_path = os.path.join(self.root_directory, destination_folder, file_name)
            shutil.move(source_path, destination_path)

        print("Files have been successfully organized into semantic folders.")

    def _flatten_directory(self):
        """
        Moves all files from subdirectories into the root directory and deletes empty directories.
        """
        for root, _, files in os.walk(self.root_directory):
            for file in files:
                source_path = os.path.join(root, file)
                destination_path = os.path.join(self.root_directory, file)
                # Avoid overwriting files with the same name
                if os.path.exists(destination_path):
                    base, ext = os.path.splitext(file)
                    counter = 1
                    while os.path.exists(destination_path):
                        new_name = f"{base}_{counter}{ext}"
                        destination_path = os.path.join(self.root_directory, new_name)
                        counter += 1
                shutil.move(source_path, destination_path)

        # Delete empty directories
        for root, dirs, _ in os.walk(self.root_directory, topdown=False):
            for dir_name in dirs:
                dir_path = os.path.join(root, dir_name)
                if not os.listdir(dir_path):  # Check if directory is empty
                    os.rmdir(dir_path)

    def _find_closest_embedding(self, centroid, embedding_matrix):
        """
        Finds the index of the embedding closest to the given centroid.

        Args:
            centroid (np.ndarray): The centroid vector.
            embedding_matrix (np.ndarray): The matrix of embeddings.

        Returns:
            int: The index of the closest embedding.
        """
        distances = ((embedding_matrix - centroid) ** 2).sum(axis=1)
        return distances.argmin()


if __name__ == "__main__":
    root_directory = r"/path/to/your/root/directory"
    input('Are you sure you want to proceed?')
    organizer = SemanticFileOrganizer(root_directory=root_directory, num_clusters=5)
    organizer.organize_files()
